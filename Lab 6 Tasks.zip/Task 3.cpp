#include <iostream>
#include <string>
using namespace std;
class Book {
private:
    string bookId;
    string bookName;
    double bookPrice;
    string bookAuthor;
    string bookISBN;

public:
    Book() {
        bookId = "";
        bookName = "";
        bookPrice = 0.0;
        bookAuthor = "";
        bookISBN = "";
    }
    Book(string id, string name, double price, string author, string isbn) {
        bookId = id;
        bookName = name;
        bookPrice = price;
        bookAuthor = author;
        bookISBN = isbn;
    }

    string getBookId() const { return bookId; }
    string getBookName() const { return bookName; }
    double getBookPrice() const { return bookPrice; }
    string getBookAuthor() const { return bookAuthor; }
    string getBookISBN() const { return bookISBN; }
    
    void setBookId(string id) { bookId = id; }
    void setBookName(string name) { bookName = name; }
    void setBookPrice(double price) { bookPrice = price; }
    void setBookAuthor(string author) { bookAuthor = author; }
    void setBookISBN(string isbn) { bookISBN = isbn; }

  
    void display() const {
        cout << "Book ID: " << bookId << "\n";
        cout << "Book Name: " << bookName << "\n";
        cout << "Author: " << bookAuthor << "\n";
        cout << "Price: $" << bookPrice << "\n";
        cout << "ISBN: " << bookISBN << "\n";
        cout << "-------------------------\n";
    }
};

class Node {
private:
    Book book;
    Node* next;
    Node* prev;

public:

    Node() {
        next = nullptr;
        prev = nullptr;
    }

    Node(Book b) {
        book = b;
        next = nullptr;
        prev = nullptr;
    }
    Book getBook() { return book; }
    Node* getNext() { return next; }
    Node* getPrev() { return prev; }

    void setBook(Book b) { book = b; }
    void setNext(Node* n) { next = n; }
    void setPrev(Node* p) { prev = p; }
};
class BookList {
private:
    Node* head;

public:
    BookList() { head = nullptr; }
    
    void addBook(string id, string name, double price, string author, string isbn) {
        Book newBook(id, name, price, author, isbn);
        Node* newNode = new Node(newBook);

        if (head == nullptr) {
            head = newNode;
            head->setNext(head);
            head->setPrev(head);
        } else {
            Node* tail = head->getPrev();
            tail->setNext(newNode);
            newNode->setPrev(tail);
            newNode->setNext(head);
            head->setPrev(newNode);
        }

        cout << "Book with ID " << id << " added successfully.\n";
    }

    void removeBook(string id) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;
        Node* toDelete = nullptr;

        do {
            if (temp->getBook().getBookId() == id) {
                toDelete = temp;
                break;
            }
            temp = temp->getNext();
        } while (temp != head);

        if (toDelete == nullptr) {
            cout << "Book with ID " << id << " not found.\n";
            return;
        }

        // Only one node
        if (toDelete->getNext() == toDelete && toDelete->getPrev() == toDelete) {
            delete toDelete;
            head = nullptr;
        }
        // Deleting head
        else if (toDelete == head) {
            Node* tail = head->getPrev();
            head = head->getNext();
            tail->setNext(head);
            head->setPrev(tail);
            delete toDelete;
        }
        // Deleting other nodes
        else {
            Node* prevNode = toDelete->getPrev();
            Node* nextNode = toDelete->getNext();
            prevNode->setNext(nextNode);
            nextNode->setPrev(prevNode);
            delete toDelete;
        }

        cout << "Book with ID " << id << " deleted successfully.\n";
    }

    // Update Book
    void updateBook(string id, string name, double price, string author, string isbn) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;
        do {
            if (temp->getBook().getBookId() == id) {
                temp->getBook().setBookName(name);
                temp->getBook().setBookPrice(price);
                temp->getBook().setBookAuthor(author);
                temp->getBook().setBookISBN(isbn);
                cout << "Book with ID " << id << " updated successfully.\n";
                return;
            }
            temp = temp->getNext();
        } while (temp != head);

        cout << "Book with ID " << id << " not found.\n";
    }

    // Print all books
    void printBooks() {
        if (head == nullptr) {
            cout << "No books available.\n";
            return;
        }

        cout << "\n--- All Books in Library ---\n";
        Node* temp = head;
        do {
            temp->getBook().display();
            temp = temp->getNext();
        } while (temp != head);
    }

    // Print specific book
    void printBook(string id) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;
        do {
            if (temp->getBook().getBookId() == id) {
                cout << "\n--- Book Details ---\n";
                temp->getBook().display();
                return;
            }
            temp = temp->getNext();
        } while (temp != head);

        cout << "Book with ID " << id << " not found.\n";
    }
};
int main() {
    BookList list;

    // Add 10 books
    for (int i = 1; i <= 10; i++) {
        list.addBook("B" + to_string(i), "Book" + to_string(i), i * 100, "Author" + to_string(i), "ISBN" + to_string(i));
    }

    // Print all books once
    list.printBooks();

    // Remove book (one valid, one invalid)
    list.removeBook("B3");   // valid
    list.removeBook("B20");  // invalid

    // Print again after deletion
    list.printBooks();

    // Update book
    list.updateBook("B5", "UpdatedBook5", 555.5, "UpdatedAuthor5", "UpdatedISBN5");

    // Print updated book
    list.printBook("B5");

    return 0;
}
