#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* next;
};
Node* head = NULL;
void display() {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }
    Node* temp = head;
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}
void insertBefore(int value) {
    Node* newNode = new Node();
    newNode->data = value;

    if (head == NULL) { 
        head = newNode;
        newNode->next = head;
    } else {
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;
        temp->next = newNode;
        newNode->next = head;
        head = newNode;  
    }
}
void insertAfter(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    if (head == NULL) { 
        head = newNode;
        newNode->next = head;
    } else {
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;
        temp->next = newNode;
        newNode->next = head;
    }
}
void deleteNode(int key) {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
}
    Node* curr = head;
    Node* prev = NULL;
    if (head->next == head && head->data == key) {
        delete head;
        head = NULL;
        cout << "Node deleted (list became empty).\n";
        return;
    }
    if (head->data == key) {
        Node* last = head;
        while (last->next != head)
            last = last->next;

        last->next = head->next;
        Node* temp = head;
        head = head->next;
        delete temp;
        cout << "Head node deleted.\n";
        return;
    }
    prev = head;
    curr = head->next;
    while (curr != head && curr->data != key) {
        prev = curr;
        curr = curr->next;
    }
    if (curr == head) {
        cout << "Node not found.\n";
        return;
    }
    prev->next = curr->next;
    delete curr;
    cout << "Node deleted successfully.\n";
}
int main() {
    cout << "--- Circular Linked List Operations ---\n";
    insertBefore(10);
    insertBefore(20);
    insertAfter(30);
    insertAfter(40);
    display();
    deleteNode(20);
    display();
    deleteNode(10);
    display();
    deleteNode(40);
    display();
    deleteNode(30);
    display();
    return 0;
}
