#include <iostream>
#include <string>
using namespace std;

struct Node {
    string name;
    Node* next;
};

Node* head = NULL;
void displayEmployees() {
    if (head == NULL) {
        cout << "No employees in the list.\n";
        return;
    }

    Node* temp = head;
    cout << "\n--- Employee List ---\n";
    do {
        cout << temp->name << endl;
        temp = temp->next;
    } while (temp != head);
    cout << "----------------------\n";
}
void addEmployee(string empName) {
    Node* newNode = new Node();
    newNode->name = empName;

    if (head == NULL) {
        head = newNode;
        newNode->next = head;
    } else {
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;

        temp->next = newNode;
        newNode->next = head;
    }
    cout << "Employee '" << empName << "' added successfully.\n";
}
bool searchEmployee(string empName) {
    if (head == NULL) {
        cout << "Employee list is empty.\n";
        return false;
    }

    Node* temp = head;
    do {
        if (temp->name == empName) {
            cout << "Employee '" << empName << "' found successfully.\n";
            return true;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Employee '" << empName << "' not found.\n";
    return false;
}
void deleteEmployee(string empName) {
    if (head == NULL) {
        cout << "List is empty. Nothing to delete.\n";
        return;
    }

    Node* curr = head;
    Node* prev = NULL;
    if (head->next == head && head->name == empName) {
        delete head;
        head = NULL;
        cout << "Employee '" << empName << "' deleted successfully.\n";
        return;
    }
    if (head->name == empName) {
        Node* last = head;
        while (last->next != head)
            last = last->next;

        last->next = head->next;
        Node* temp = head;
        head = head->next;
        delete temp;
        cout << "Employee '" << empName << "' deleted successfully.\n";
        return;
    }

    prev = head;
    curr = head->next;
    while (curr != head && curr->name != empName) {
        prev = curr;
        curr = curr->next;
    }

    if (curr == head) {
        cout << "Employee '" << empName << "' not found.\n";
        return;
    }

    prev->next = curr->next;
    delete curr;
    cout << "Employee '" << empName << "' deleted successfully.\n";
}
void updateEmployee(string oldName, string newName) {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }

    Node* temp = head;
    do {
        if (temp->name == oldName) {
            temp->name = newName;
            cout << "Employee name updated from '" << oldName << "' to '" << newName << "' successfully.\n";
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Employee '" << oldName << "' not found.\n";
}

int main() {
    int choice;
    string empName, oldName, newName;

    do {
        cout << "\n====== Employee Management (Circular Linked List) ======\n";
        cout << "1. Add Employee\n";
        cout << "2. Delete Employee\n";
        cout << "3. Search Employee\n";
        cout << "4. Update Employee Name\n";
        cout << "5. Display All Employees\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1:
            cout << "Enter employee name to add: ";
            getline(cin, empName);
            addEmployee(empName);
            break;
        case 2:
            cout << "Enter employee name to delete: ";
            getline(cin, empName);
            deleteEmployee(empName);
            break;
        case 3:
            cout << "Enter employee name to search: ";
            getline(cin, empName);
            searchEmployee(empName);
            break;
        case 4:
            cout << "Enter current employee name: ";
            getline(cin, oldName);
            cout << "Enter new name: ";
            getline(cin, newName);
            updateEmployee(oldName, newName);
            break;
        case 5:
            displayEmployees();
            break;
        case 0:
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 0);

    return 0;
}
